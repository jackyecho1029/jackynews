# High Agency Learning Coach - Examples

## Example 1: Learning Prompt Engineering

### Initial Conversation

**User**: 我想学习 Prompt Engineering，帮我制定学习计划

**Coach**: 太好了！Prompt Engineering 是2026年最热门的技能之一。让我问几个问题来定制你的学习计划：

**1. 学习目标？**
- A. 入门了解（能写出基础prompt，1-2周）
- B. 能独立做项目（优化产品的AI功能，1-3个月）
- C. 成为专家（能设计复杂的AI系统，6-12个月）

**User**: B，我想能独立做项目

**Coach**: 很好！

**2. 当前基础？**
- A. 完全零基础，没用过ChatGPT
- B. 用过ChatGPT，但都是简单对话
- C. 已经在工作中使用AI工具

**User**: B

**Coach**: 

**3. 每天能投入多少时间？**
- A. 1-2小时（业余学习）
- B. 3-5小时（重点突破）
- C. 全职学习（快速转型）

**User**: A，每天1-2小时

**Coach**:

**4. 学习动机？**
- A. 工作需要
- B. 个人兴趣
- C. 创业项目
- D. 职业转型

**User**: C，我想做一个AI产品

**Coach**:

**5. 你想做出什么可展示的作品？**

（描述一下你的理想项目）

**User**: 我想做一个AI写作助手，帮助写营销文案

**Coach**: 完美！这是一个很好的项目选择 - 实用、可展示、有市场需求。

---

### Generated Learning Plan

根据你的情况，我为你生成了专属的 **30天 Prompt Engineering 学习计划**：

**学习路径**: 业余深度学习模式（每天1.5-2小时）  
**最终作品**: AI营销文案助手  
**技术栈**: OpenAI API + Python/JavaScript + Streamlit  

#### Week 1: 快速入门（7天）
- Day 1-2: 理解prompt基础结构
- Day 3-5: 实践Few-shot Learning
- Day 6-7: 完成第一个简单的文案生成器

**Week 1 目标**: 有一个能运行的基础版本

#### Week 2: 深入实践（7天）
- Day 8-10: 学习Chain-of-Thought
- Day 11-14: 实现文案分类功能（广告/邮件/社交媒体）

**Week 2 目标**: 核心功能完成，能生成3种文案

#### Week 3: 优化提升（7天）
- Day 15-18: Prompt优化技巧
- Day 19-21: 添加用户自定义风格

**Week 3 目标**: 文案质量显著提升，有个性化功能

#### Week 4: 完善发布（9天）
- Day 22-25: UI/UX优化
- Day 26-28: 写文档，录demo视频
- Day 29-30: 发布到GitHub和ProductHunt

**Week 4 目标**: 完整作品公开发布

---

**推荐资源**:
- 📖 必读: OpenAI Prompt Engineering Guide
- 🎥 视频: [具体推荐]
- 💻 参考项目: [GitHub优秀项目]

**学习计划已保存到**:  
`d:/Antigravity/Jackypotato/learning-plans/prompt-engineering/plan.md`

**准备好开始了吗？回复"今天开始学习 Prompt Engineering"来开始你的第一天！** 🚀

---

## Example 2: Daily Check-in

**User**: 今天开始学习 Prompt Engineering

**Coach**: 早上好！欢迎来到 Prompt Engineering 学习的第1天！ 🎉

📊 **今天的状态**:
- 计划: Day 1/30
- 本周目标: 理解prompt基础结构
- 进度: 0% → 准备起飞！

🎯 **今天的3个具体任务**（预计1.5小时）:

**任务1: 理解Prompt结构（30分钟）**
- 阅读: [OpenAI Prompt Guide - 基础部分]
- 理解: System, User, Assistant三个角色
- **输出**: 在笔记记下关键概念

**任务2: 动手实践（45分钟）**
使用这个提示词模板练习:
```python
system_prompt = "你是一个专业的营销文案撰写专家"
user_prompt = "帮我写一个产品的宣传标语：[你的产品]"

# 尝试3次，观察输出变化
```

**任务3: 记录和分享（15分钟）**
- 写下今天学到的最重要的1个概念
- 发一条Twitter分享学习开始
- **模板**: "今天开始30天学习Prompt Engineering挑战！Day 1: 理解了prompt的基本结构。#BuildInPublic"

💡 **今天的重点提示**:
不要追求理解所有细节。今天重点是"动手试"，感受AI如何响应不同的prompt。

🔗 **资源准备**:
- 注册OpenAI账号（如还没有）
- 准备一个代码编辑器或用ChatGPT网页版

有任何问题随时问我！开始后告诉我进展如何 💪

---

## Example 3: Stuck & Need Help

**User**: Prompt Engineering 学习遇到问题：我的prompt生成的文案总是很机械，没有吸引力

**Coach**: 这是一个非常常见且重要的问题！让我帮你诊断和解决：

🔍 **问题诊断**:
文案"机械"通常是因为：
1. Prompt太简单，没给足够上下文
2. 没有指定语气和风格
3. 缺少few-shot examples

🛠️ **立即可用的解决方案**:

**改进前** (你可能在用的):
```
写一个产品宣传文案
```

**改进后** (试试这个):
```
你是一个顶级营销文案大师，擅长写有感染力的广告语。

写作风格：
- 语气：热情但不夸张
- 句式：短句，有节奏感
- 手法：使用具体数字和视觉化描述

示例1：
产品：运动鞋
文案："一步跨越26.2公里。轻如空气，稳如磐石。"

示例2：
产品：咖啡机
文案："3分钟，从豆到杯。每一口都是咖啡师的匠心。"

现在，请为以下产品写文案：
产品：[你的产品]
```

📖 **学习建议**:
1. 今天的任务改为"Few-shot Learning专项练习"
2. 找3个你欣赏的文案，当作examples
3. 逐个添加约束条件（语气、长度、风格）观察变化

🎯 **练习任务**:
拿你的产品，用上面的改进版prompt:
1. 先用基础版生成
2. 再用改进版生成
3. 对比差异，记录学习笔记

试试看，然后告诉我效果如何！如果还有问题我们继续优化。

---

## Example 4: Daily Summary

**User**: 今天学习总结 Prompt Engineering

**Coach**: 太好了！让我们回顾今天的进展并记录下来。

请回答以下问题（简短即可）:

1. **今天完成了哪些任务？**

2. **学到的最重要的东西是什么？**

3. **遇到了什么问题？解决了吗？**

4. **明天想重点突破什么？**

5. **今天有公开分享吗？（Twitter/GitHub/Blog）**

---

*（用户回答后）*

**Coach**: 很棒的进展！让我更新你的学习记录：

📊 **Day 1 完成情况**:
✅ 理解了prompt基础结构  
✅ 完成了3个实践练习  
✅ 发了第一条学习Twitter  
⚠️ Few-shot部分还有些困惑（明天重点）

📝 **学习日志已更新**:
保存在: `learning-plans/prompt-engineering/daily-log.md`

🎯 **明天计划**（Day 2）:
基于今天的情况，我建议明天：

**主任务**: 深入Few-shot Learning
- 练习时间: 1小时
- 目标: 能用3个example提升文案质量

**次任务**: 开始搭建项目框架
- 用Python基础调用OpenAI API
- 目标: 能运行Hello World

💪 **鼓励**:
第一天你已经迈出了最重要的一步！很多人卡在"准备"阶段，但你已经在"做"了。Keep going!

⏰ **明天见**:
明天同一时间，说"今天开始学习 Prompt Engineering"，我会给你Day 2的详细任务。

今天早点休息，明天继续加油！ 🚀

---

## Example 5: Project Review

**User**: Review我的 Prompt Engineering 作品：https://github.com/user/ai-copywriter

**Coach**: 太棒了！让我详细review你的AI文案助手项目 🎉

*（查看GitHub仓库后）*

## 🌟 总体评价: B+ (Very Good!)

这是一个30天学习后的优秀成果！

---

## ✅ 做得好的地方

### 1. 项目完整性 (A)
- ✅ 有清晰的README
- ✅ 代码结构合理
- ✅ 功能基本完整

### 2. Prompt设计 (B+)
```python
# 你的代码
system_prompt = "你是营销文案专家..."
```
- ✅ 有明确的role定义
- ✅ 使用了few-shot examples
- ⚠️ 可以更结构化（见改进建议）

### 3. 代码质量 (B)
- ✅ 有基本的错误处理
- ✅ 注释清晰
- ⚠️ 缺少测试

---

## 💡 改进建议（按优先级）

### 优先级1: Prompt优化（技术深度）

**当前代码**:
```python
system_prompt = "你是营销文案专家，请写文案"
```

**建议改为**:
```python
system_prompt = """
你是一位有15年经验的营销文案专家。

核心能力：
- 深入理解产品价值主张
- 精通消费心理学
- 擅长A/B测试优化文案

写作原则：
1. 利益先行（客户获得什么，而非产品是什么）
2. 具体化数字（不说"很快"，说"3分钟"）
3. 制造紧迫感（限时/限量/独家）

输出格式：
- 标题：10字以内，有悬念
- 正文：3段，每段30字左右
- CTA：1句，动词开头
"""
```

**效果提升**: 文案质量会从60分→85分

### 优先级2: 添加流式输出（用户体验）

当前是一次性返回，用户等待体验不好。

建议添加：
```python
def generate_copy_stream(product_info):
    for chunk in openai.ChatCompletion.create(
        model="gpt-4",
        messages=messages,
        stream=True  # 关键！
    ):
        yield chunk
```

### 优先级3: 添加Prompt版本管理

建议结构：
```
prompts/
  ├── v1_basic.py
  ├── v2_improved.py
  └── v3_advanced.py
```

这样可以：
- A/B测试不同prompt
- 回滚到之前版本
- 记录改进历史

---

## 📈 下一步建议

你现在处于"能做出来"阶段，选择一个方向深入：

### 路线A: 技术深度
- 研究Advanced Prompt Techniques
- 实现Chain-of-Thought reasoning
- 添加RAG（检索增强生成）
- **适合**: 想成为Prompt Engineering专家

### 路线B: 产品化
- 添加用户账号系统
- 实现文案历史记录
- A/B测试功能
- **适合**: 想做真实产品

### 路线C: 扩展作品集
- 做2-3个不同的AI工具
- 展示多样化能力
- **适合**: 求职或接项目

**我的建议**: 基于你的创业目标，选**路线B**。

---

## 📢 展示和推广建议

### 立即行动（本周内）:

1. **录制Demo视频**（5分钟）
   - 展示3个使用场景
   - 对比AI前后的文案
   - 发布到Twitter和LinkedIn

2. **写技术博客**
   - 标题: "我如何用30天学会Prompt Engineering并做了这个工具"
   - 包含: 学习历程、技术挑战、效果展示
   - 发布平台: Medium + 自己博客

3. **社区分享**
   - ProductHunt发布
   - Hacker News分享
   - Reddit r/SideProject

### 推广文案模板:
```
🚀 30天学习挑战：从零到AI文案助手

我完全没有AI背景，通过30天的High Agency学习，
做出了这个AI营销文案生成器。

✅ 自动生成3种文案格式
✅ 基于GPT-4优化prompt
✅ 100%开源

GitHub: [链接]
Demo: [链接]

#BuildInPublic #AI #Marketing
```

---

## 🎯 评分详情

| 维度 | 得分 | 说明 |
|------|------|------|
| 项目完整性 | A | 功能完整，文档清晰 |
| 技术实现 | B+ | 基础扎实，有优化空间 |
| 代码质量 | B | 可读性好，缺少测试 |
| 创新性 | B | 实用项目，执行到位 |
| 可展示性 | A- | 易于演示，缺少视频 |

**总评**: B+ (Very Good!)

对于30天的学习成果，这已经超过了80%的学习者。

---

## 💪 最后的话

你用30天完成了从0到1的跨越，这本身就是巨大的成功。

**记住Gabriel的故事**: 他也是从第一个项目开始，经过持续优化和展示，最终进入OpenAI。

你现在要做的：
1. 持续优化这个项目（每周1小时）
2. 公开展示并获得反馈
3. 开始下一个项目（重复飞轮）

**3个月后，你会有3个这样的作品。到时候，机会会主动找到你。**

继续加油！随时来找我review新进展 🚀
